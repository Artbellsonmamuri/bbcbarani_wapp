"""
Real-time notifications API serializers
"""
from rest_framework import serializers

# API serializers will be added here
