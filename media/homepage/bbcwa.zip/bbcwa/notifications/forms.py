"""
Real-time notifications forms
"""
from django import forms

# Django forms will be added here
