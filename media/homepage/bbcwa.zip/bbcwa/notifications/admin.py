"""
Real-time notifications admin configuration
"""
from django.contrib import admin

# Register your models here
