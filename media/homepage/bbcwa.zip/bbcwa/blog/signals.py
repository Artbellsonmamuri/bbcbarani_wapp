"""
Blog system with comments signals
"""
from django.db.models.signals import post_save
from django.dispatch import receiver

# Signal handlers will be added here
