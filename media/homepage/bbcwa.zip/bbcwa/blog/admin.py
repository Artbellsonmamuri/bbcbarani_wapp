"""
Blog system with comments admin configuration
"""
from django.contrib import admin

# Register your models here
