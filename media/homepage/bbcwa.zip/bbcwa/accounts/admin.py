"""
User authentication and profiles admin configuration
"""
from django.contrib import admin

# Register your models here
