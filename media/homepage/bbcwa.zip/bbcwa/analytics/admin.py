"""
Site analytics tracking admin configuration
"""
from django.contrib import admin

# Register your models here
