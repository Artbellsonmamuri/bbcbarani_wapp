"""
Event calendar and RSVP admin configuration
"""
from django.contrib import admin

# Register your models here
